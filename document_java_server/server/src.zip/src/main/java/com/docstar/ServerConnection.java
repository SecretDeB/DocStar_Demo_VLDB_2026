package com.docstar;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ServerConnection {
    @SuppressWarnings("unused")
    private final int serverNumber;
    private Socket socket;
    private ObjectOutputStream out;
    public ObjectInputStream in;
    private final Object sendLock = new Object();

    public ServerConnection(int serverNumber, String ip, int port) throws IOException {
        this.serverNumber = serverNumber;
        connect(ip, port);
    }

    public void send(Object message) throws IOException {
        synchronized (sendLock) {
            out.writeObject(message);
            out.flush();
        }
    }

    public Object receive() throws IOException, ClassNotFoundException {
        return in.readObject();
    }

    private void connect(String ip, int port) throws IOException {
        this.socket = new Socket(ip, port);
        this.out = new ObjectOutputStream(socket.getOutputStream());
        this.in = new ObjectInputStream(socket.getInputStream());
    }

}