package com.docstar;

import java.io.Serializable;

public class FileShare implements Serializable {
    private int serverNumber;
    private long[] fileShare;

    public FileShare(int serverNumber, long[] fileShare) {
        this.serverNumber = serverNumber;
        this.fileShare = fileShare;
    }

    public int getServerNumber() {
        return serverNumber;
    }

    public long[] getFileShare() {
        return fileShare;
    }
}
